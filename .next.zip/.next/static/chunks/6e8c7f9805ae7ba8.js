__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/0fb29ca28aca7adf.js",
  "static/chunks/turbopack-5dbdcc5c82490d98.js"
])
