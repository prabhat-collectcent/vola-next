globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/0fb29ca28aca7adf.js",
      "static/chunks/turbopack-5dbdcc5c82490d98.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/0fb29ca28aca7adf.js",
      "static/chunks/turbopack-9210d12637137af4.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/146f90d7c1a7ab0a.js",
    "static/chunks/c5e2b4362f0caf43.js",
    "static/chunks/b7bac94bf10fcc30.js",
    "static/chunks/245ff668de548b2d.js",
    "static/chunks/522518d740397639.js",
    "static/chunks/d68b03ea66d062a5.js",
    "static/chunks/turbopack-e7119c648323f447.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];