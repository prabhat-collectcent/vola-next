var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/[...nextauth]/route.js")
R.c("server/chunks/[root-of-the-server]__7cdd1ecd._.js")
R.c("server/chunks/node_modules_c2d1ee63._.js")
R.m(43433)
R.m(3413)
module.exports=R.m(3413).exports
